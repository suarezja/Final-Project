from numpy import nan
from sagemaker_sklearn_extension.externals import Header
from sagemaker_sklearn_extension.impute import RobustImputer
from sagemaker_sklearn_extension.preprocessing import RobustLabelEncoder
from sagemaker_sklearn_extension.preprocessing import RobustStandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

# Given a list of column names and target column name, Header can return the index
# for given column name
HEADER = Header(
    column_names=[
        'Rain', 'DATE', 'MONTH', 'BASEL_cloud_cover', 'BASEL_humidity',
        'BASEL_pressure', 'BASEL_global_radiation', 'BASEL_precipitation',
        'BASEL_sunshine', 'BASEL_temp_mean', 'BASEL_temp_min', 'BASEL_temp_max',
        'BUDAPEST_cloud_cover', 'BUDAPEST_humidity', 'BUDAPEST_pressure',
        'BUDAPEST_global_radiation', 'BUDAPEST_precipitation',
        'BUDAPEST_sunshine', 'BUDAPEST_temp_mean', 'BUDAPEST_temp_max',
        'DE_BILT_cloud_cover', 'DE_BILT_wind_speed', 'DE_BILT_wind_gust',
        'DE_BILT_humidity', 'DE_BILT_pressure', 'DE_BILT_global_radiation',
        'DE_BILT_precipitation', 'DE_BILT_sunshine', 'DE_BILT_temp_mean',
        'DE_BILT_temp_min', 'DE_BILT_temp_max', 'DRESDEN_cloud_cover',
        'DRESDEN_wind_speed', 'DRESDEN_wind_gust', 'DRESDEN_humidity',
        'DRESDEN_global_radiation', 'DRESDEN_precipitation', 'DRESDEN_sunshine',
        'DRESDEN_temp_mean', 'DRESDEN_temp_min', 'DRESDEN_temp_max',
        'DUSSELDORF_cloud_cover', 'DUSSELDORF_wind_speed',
        'DUSSELDORF_wind_gust', 'DUSSELDORF_humidity', 'DUSSELDORF_pressure',
        'DUSSELDORF_global_radiation', 'DUSSELDORF_precipitation',
        'DUSSELDORF_sunshine', 'DUSSELDORF_temp_mean', 'DUSSELDORF_temp_min',
        'DUSSELDORF_temp_max', 'HEATHROW_cloud_cover', 'HEATHROW_humidity',
        'HEATHROW_pressure', 'HEATHROW_global_radiation',
        'HEATHROW_precipitation', 'HEATHROW_sunshine', 'HEATHROW_temp_mean',
        'HEATHROW_temp_min', 'HEATHROW_temp_max', 'KASSEL_wind_speed',
        'KASSEL_wind_gust', 'KASSEL_humidity', 'KASSEL_pressure',
        'KASSEL_global_radiation', 'KASSEL_precipitation', 'KASSEL_sunshine',
        'KASSEL_temp_mean', 'KASSEL_temp_min', 'KASSEL_temp_max',
        'LJUBLJANA_cloud_cover', 'LJUBLJANA_wind_speed', 'LJUBLJANA_humidity',
        'LJUBLJANA_pressure', 'LJUBLJANA_global_radiation',
        'LJUBLJANA_precipitation', 'LJUBLJANA_sunshine', 'LJUBLJANA_temp_mean',
        'LJUBLJANA_temp_min', 'LJUBLJANA_temp_max', 'MAASTRICHT_cloud_cover',
        'MAASTRICHT_wind_speed', 'MAASTRICHT_wind_gust', 'MAASTRICHT_humidity',
        'MAASTRICHT_pressure', 'MAASTRICHT_global_radiation',
        'MAASTRICHT_precipitation', 'MAASTRICHT_sunshine',
        'MAASTRICHT_temp_mean', 'MAASTRICHT_temp_min', 'MAASTRICHT_temp_max',
        'MALMO_wind_speed', 'MALMO_precipitation', 'MALMO_temp_mean',
        'MALMO_temp_min', 'MALMO_temp_max', 'MONTELIMAR_wind_speed',
        'MONTELIMAR_humidity', 'MONTELIMAR_pressure',
        'MONTELIMAR_global_radiation', 'MONTELIMAR_precipitation',
        'MONTELIMAR_temp_mean', 'MONTELIMAR_temp_min', 'MONTELIMAR_temp_max',
        'MUENCHEN_cloud_cover', 'MUENCHEN_wind_speed', 'MUENCHEN_wind_gust',
        'MUENCHEN_humidity', 'MUENCHEN_pressure', 'MUENCHEN_global_radiation',
        'MUENCHEN_precipitation', 'MUENCHEN_sunshine', 'MUENCHEN_temp_mean',
        'MUENCHEN_temp_min', 'MUENCHEN_temp_max', 'OSLO_cloud_cover',
        'OSLO_wind_speed', 'OSLO_wind_gust', 'OSLO_humidity', 'OSLO_pressure',
        'OSLO_global_radiation', 'OSLO_precipitation', 'OSLO_sunshine',
        'OSLO_temp_mean', 'OSLO_temp_min', 'OSLO_temp_max',
        'PERPIGNAN_wind_speed', 'PERPIGNAN_humidity', 'PERPIGNAN_pressure',
        'PERPIGNAN_global_radiation', 'PERPIGNAN_precipitation',
        'PERPIGNAN_temp_mean', 'PERPIGNAN_temp_min', 'PERPIGNAN_temp_max',
        'ROMA_cloud_cover', 'ROMA_humidity', 'ROMA_pressure',
        'ROMA_global_radiation', 'ROMA_sunshine', 'ROMA_temp_mean',
        'ROMA_temp_min', 'ROMA_temp_max', 'SONNBLICK_cloud_cover',
        'SONNBLICK_humidity', 'SONNBLICK_global_radiation',
        'SONNBLICK_precipitation', 'SONNBLICK_sunshine', 'SONNBLICK_temp_mean',
        'SONNBLICK_temp_min', 'SONNBLICK_temp_max', 'STOCKHOLM_cloud_cover',
        'STOCKHOLM_pressure', 'STOCKHOLM_precipitation', 'STOCKHOLM_sunshine',
        'STOCKHOLM_temp_mean', 'STOCKHOLM_temp_min', 'STOCKHOLM_temp_max',
        'TOURS_wind_speed', 'TOURS_humidity', 'TOURS_pressure',
        'TOURS_global_radiation', 'TOURS_precipitation', 'TOURS_temp_mean',
        'TOURS_temp_min', 'TOURS_temp_max'
    ],
    target_column_name='Rain'
)


def build_feature_transform():
    """ Returns the model definition representing feature processing."""

    # These features can be parsed as numeric.

    numeric = HEADER.as_feature_indices(
        [
            'DATE', 'MONTH', 'BASEL_cloud_cover', 'BASEL_humidity',
            'BASEL_pressure', 'BASEL_global_radiation', 'BASEL_precipitation',
            'BASEL_sunshine', 'BASEL_temp_mean', 'BASEL_temp_min',
            'BASEL_temp_max', 'BUDAPEST_cloud_cover', 'BUDAPEST_humidity',
            'BUDAPEST_pressure', 'BUDAPEST_global_radiation',
            'BUDAPEST_precipitation', 'BUDAPEST_sunshine', 'BUDAPEST_temp_mean',
            'BUDAPEST_temp_max', 'DE_BILT_cloud_cover', 'DE_BILT_wind_speed',
            'DE_BILT_wind_gust', 'DE_BILT_humidity', 'DE_BILT_pressure',
            'DE_BILT_global_radiation', 'DE_BILT_precipitation',
            'DE_BILT_sunshine', 'DE_BILT_temp_mean', 'DE_BILT_temp_min',
            'DE_BILT_temp_max', 'DRESDEN_cloud_cover', 'DRESDEN_wind_speed',
            'DRESDEN_wind_gust', 'DRESDEN_humidity', 'DRESDEN_global_radiation',
            'DRESDEN_precipitation', 'DRESDEN_sunshine', 'DRESDEN_temp_mean',
            'DRESDEN_temp_min', 'DRESDEN_temp_max', 'DUSSELDORF_cloud_cover',
            'DUSSELDORF_wind_speed', 'DUSSELDORF_wind_gust',
            'DUSSELDORF_humidity', 'DUSSELDORF_pressure',
            'DUSSELDORF_global_radiation', 'DUSSELDORF_precipitation',
            'DUSSELDORF_sunshine', 'DUSSELDORF_temp_mean',
            'DUSSELDORF_temp_min', 'DUSSELDORF_temp_max',
            'HEATHROW_cloud_cover', 'HEATHROW_humidity', 'HEATHROW_pressure',
            'HEATHROW_global_radiation', 'HEATHROW_precipitation',
            'HEATHROW_sunshine', 'HEATHROW_temp_mean', 'HEATHROW_temp_min',
            'HEATHROW_temp_max', 'KASSEL_wind_speed', 'KASSEL_wind_gust',
            'KASSEL_humidity', 'KASSEL_pressure', 'KASSEL_global_radiation',
            'KASSEL_precipitation', 'KASSEL_sunshine', 'KASSEL_temp_mean',
            'KASSEL_temp_min', 'KASSEL_temp_max', 'LJUBLJANA_cloud_cover',
            'LJUBLJANA_wind_speed', 'LJUBLJANA_humidity', 'LJUBLJANA_pressure',
            'LJUBLJANA_global_radiation', 'LJUBLJANA_precipitation',
            'LJUBLJANA_sunshine', 'LJUBLJANA_temp_mean', 'LJUBLJANA_temp_min',
            'LJUBLJANA_temp_max', 'MAASTRICHT_cloud_cover',
            'MAASTRICHT_wind_speed', 'MAASTRICHT_wind_gust',
            'MAASTRICHT_humidity', 'MAASTRICHT_pressure',
            'MAASTRICHT_global_radiation', 'MAASTRICHT_precipitation',
            'MAASTRICHT_sunshine', 'MAASTRICHT_temp_mean',
            'MAASTRICHT_temp_min', 'MAASTRICHT_temp_max', 'MALMO_wind_speed',
            'MALMO_precipitation', 'MALMO_temp_mean', 'MALMO_temp_min',
            'MALMO_temp_max', 'MONTELIMAR_wind_speed', 'MONTELIMAR_humidity',
            'MONTELIMAR_pressure', 'MONTELIMAR_global_radiation',
            'MONTELIMAR_precipitation', 'MONTELIMAR_temp_mean',
            'MONTELIMAR_temp_min', 'MONTELIMAR_temp_max',
            'MUENCHEN_cloud_cover', 'MUENCHEN_wind_speed', 'MUENCHEN_wind_gust',
            'MUENCHEN_humidity', 'MUENCHEN_pressure',
            'MUENCHEN_global_radiation', 'MUENCHEN_precipitation',
            'MUENCHEN_sunshine', 'MUENCHEN_temp_mean', 'MUENCHEN_temp_min',
            'MUENCHEN_temp_max', 'OSLO_cloud_cover', 'OSLO_wind_speed',
            'OSLO_wind_gust', 'OSLO_humidity', 'OSLO_pressure',
            'OSLO_global_radiation', 'OSLO_precipitation', 'OSLO_sunshine',
            'OSLO_temp_mean', 'OSLO_temp_min', 'OSLO_temp_max',
            'PERPIGNAN_wind_speed', 'PERPIGNAN_humidity', 'PERPIGNAN_pressure',
            'PERPIGNAN_global_radiation', 'PERPIGNAN_precipitation',
            'PERPIGNAN_temp_mean', 'PERPIGNAN_temp_min', 'PERPIGNAN_temp_max',
            'ROMA_cloud_cover', 'ROMA_humidity', 'ROMA_pressure',
            'ROMA_global_radiation', 'ROMA_sunshine', 'ROMA_temp_mean',
            'ROMA_temp_min', 'ROMA_temp_max', 'SONNBLICK_cloud_cover',
            'SONNBLICK_humidity', 'SONNBLICK_global_radiation',
            'SONNBLICK_precipitation', 'SONNBLICK_sunshine',
            'SONNBLICK_temp_mean', 'SONNBLICK_temp_min', 'SONNBLICK_temp_max',
            'STOCKHOLM_cloud_cover', 'STOCKHOLM_pressure',
            'STOCKHOLM_precipitation', 'STOCKHOLM_sunshine',
            'STOCKHOLM_temp_mean', 'STOCKHOLM_temp_min', 'STOCKHOLM_temp_max',
            'TOURS_wind_speed', 'TOURS_humidity', 'TOURS_pressure',
            'TOURS_global_radiation', 'TOURS_precipitation', 'TOURS_temp_mean',
            'TOURS_temp_min', 'TOURS_temp_max'
        ]
    )

    numeric_processors = Pipeline(
        steps=[
            (
                'robustimputer',
                RobustImputer(strategy='constant', fill_values=nan)
            )
        ]
    )

    column_transformer = ColumnTransformer(
        transformers=[('numeric_processing', numeric_processors, numeric)]
    )

    return Pipeline(
        steps=[
            ('column_transformer', column_transformer
            ), ('robuststandardscaler', RobustStandardScaler())
        ]
    )


def build_label_transform():
    """Returns the model definition representing feature processing."""

    return RobustLabelEncoder(
        labels=['0'], fill_label_value='1', include_unseen_class=True
    )
